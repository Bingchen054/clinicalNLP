from fastapi import FastAPI, UploadFile, File  
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import re
from typing import List, Optional
import pdfplumber   


app = FastAPI()

# Allow frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnalyzeRequest(BaseModel):
    note: str


# -----------------------------
# Troponin Extraction
# -----------------------------
def parse_troponins(text: str) -> List[float]:
    patterns = [
        r"troponin(?:\s*[it])?\s*[:\-]?\s*(\d+\.\d+|\d+)(?=\s|$|[^0-9./])",
        r"troponin(?:\s*[it])?.*?(\d+\.\d+|\d+)\s*(?:ng\/?ml|ngml)?",
    ]

    values = []

    for pattern in patterns:
        for match in re.findall(pattern, text, flags=re.IGNORECASE):
            try:
                values.append(float(match))
            except:
                pass

    for match in re.findall(r"(\d+\.\d+|\d+)\s*(?:ng\/?ml|ngml)", text, flags=re.IGNORECASE):
        try:
            values.append(float(match))
        except:
            pass

    return sorted(set(values))


# -----------------------------
# SBP Extraction
# -----------------------------
def parse_systolic_bp(text: str) -> Optional[int]:

    # Format: 85/60
    m = re.search(r"\b(\d{2,3})\s*/\s*(\d{2,3})\b", text, flags=re.IGNORECASE)
    if m:
        return int(m.group(1))

    # Format: BP 85
    m = re.search(r"\bbp[:\s]*?(\d{2,3})\b", text, flags=re.IGNORECASE)
    if m:
        return int(m.group(1))

    # Format: SBP 120 or Systolic BP 120
    m = re.search(r"\b(?:sbp|systolic\s*bp)[:\s]*?(\d{2,3})\b", text, flags=re.IGNORECASE)
    if m:
        return int(m.group(1))

    # Format: 85 over 60
    m = re.search(r"\b(\d{2,3})\s*over\s*(\d{2,3})\b", text, flags=re.IGNORECASE)
    if m:
        return int(m.group(1))

    return None


# -----------------------------
# Hypotension Semantic Detection
# -----------------------------
def detect_hypotension_terms(text: str) -> bool:
    patterns = [
        r"\bhypotens(?:ive|ion)\b",
        r"\blower\s+blood\s+pressure\b",
        r"\bhemodynam(ic)?\s*instab",
        r"\bsystolic\s*bp\s*<\s*90\b",
        r"\bsbp\s*<\s*90\b",
    ]

    for pattern in patterns:
        if re.search(pattern, text, flags=re.IGNORECASE):
            return True

    return False


# -----------------------------
# Main Analyze Endpoint
# -----------------------------
@app.post("/analyze")
def analyze(data: AnalyzeRequest):

    note = data.note or ""
    text = note

    troponin_values = parse_troponins(text)
    troponin_value = max(troponin_values) if troponin_values else None

    systolic = parse_systolic_bp(text)
    hypotension_flag = detect_hypotension_terms(text)

    missing_criteria = []
    enhancements = []

    # -------------------------
    # Troponin Rule
    # -------------------------
    if troponin_value is not None:
        troponin_status = "Met" if troponin_value > 0.04 else "Partial"
        troponin_evidence = f"Troponin value {troponin_value}"

        if troponin_value > 0.04:
            enhancements.append(
                f"Elevated troponin level ({troponin_value} ng/mL) supports acute myocardial injury meeting MCG Section 1.1 inpatient admission criteria."
            )
    else:
        troponin_status = "Missing"
        troponin_evidence = "No troponin documented"

    missing_criteria.append({
        "criteria": "Troponin documentation",
        "status": troponin_status,
        "confidence": 95,
        "evidence": troponin_evidence,
        "guideline": "MCG Section 1.1",
        "action": "Document troponin level" if troponin_status == "Missing" else "No action needed"
    })

    # -------------------------
    # Hemodynamic Rule
    # -------------------------
    if systolic is not None:
        if systolic < 90 or hypotension_flag:
            bp_status = "Met"
            bp_evidence = f"Systolic BP {systolic}"

            enhancements.append(
                f"Hemodynamic instability documented with systolic BP {systolic} mmHg meeting MCG Section 2.1 criteria for inpatient-level monitoring."
            )
        else:
            bp_status = "Partial"
            bp_evidence = f"Systolic BP {systolic}"
    else:
        if hypotension_flag:
            bp_status = "Met"
            bp_evidence = "Hypotension language found"

            enhancements.append(
                "Clinical documentation indicates hypotension requiring inpatient-level monitoring."
            )
        else:
            bp_status = "Missing"
            bp_evidence = "No BP documented"

    missing_criteria.append({
        "criteria": "Hemodynamic instability",
        "status": bp_status,
        "confidence": 90,
        "evidence": bp_evidence,
        "guideline": "MCG Section 2.1",
        "action": "Document blood pressure" if bp_status == "Missing" else "No action needed"
    })

    # -------------------------
    # Final Revised Text
    # -------------------------
    enhanced_text = note
    if enhancements:
        enhanced_text += "\n\n" + "\n".join(enhancements)

    return {
        "revisedNote": enhanced_text,
        "missingCriteria": missing_criteria
    }

# -----------------------------
# PDF Upload Endpoint
# -----------------------------
@app.post("/upload-pdf")
async def upload_pdf(file: UploadFile = File(...)):
    text = ""

    try:
        with pdfplumber.open(file.file) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"

        return {
            "filename": file.filename,
            "text": text
        }

    except Exception as e:
        return {"error": str(e)}

# -----------------------------
# Upload + Analyze Combined
# -----------------------------
@app.post("/upload-and-analyze")
async def upload_and_analyze(file: UploadFile = File(...)):

    text = ""

    try:
        with pdfplumber.open(file.file) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"

        # 直接调用现有 analyze 逻辑
        result = analyze(AnalyzeRequest(note=text))

        return {
            "filename": file.filename,
            "analysis": result
        }

    except Exception as e:
        return {"error": str(e)}
